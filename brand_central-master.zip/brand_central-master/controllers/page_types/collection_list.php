<?php

namespace Concrete\Package\BrandCentral\Controller\PageType;

use Concrete\Core\Page\Controller\PageTypeController;

class CollectionList extends PageTypeController
{
}
