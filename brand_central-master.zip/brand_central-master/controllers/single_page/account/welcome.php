<?php

namespace Concrete\Package\BrandCentral\Controller\SinglePage\Account;

use Concrete\Core\Page\Controller\AccountPageController;

class Welcome extends AccountPageController
{

}
