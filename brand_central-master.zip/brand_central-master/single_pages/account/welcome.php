<?php defined('C5_EXECUTE') or die("Access Denied."); ?>

<?php

$a = new Area('Main');
$a->display($c);

?>