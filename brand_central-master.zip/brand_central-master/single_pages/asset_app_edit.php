
<script src="<?= $view->getThemePath() ?>/js/asset.js"></script>

<div id="asset" data-asset="<?= $asset->getId() ?>"></div>

