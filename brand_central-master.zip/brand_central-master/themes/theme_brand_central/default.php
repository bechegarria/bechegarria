<?php
defined('C5_EXECUTE') or die(_("Access Denied."));
$this->inc('elements/header.php');
?>

    <div class="container">
        <div class="row">
            <div class="col-12">
                <div class="blank-space"></div>
            </div>
        </div>
    </div>

<?php  $this->inc('elements/footer.php'); ?>
