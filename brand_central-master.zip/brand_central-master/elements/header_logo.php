<?php defined('C5_EXECUTE') or die(_("Access Denied.")); ?>

<div class="col-md-3 col-2 main-nav-branding">
    <a href="<?=URL::to('/')?>">
        <img class="logo" src="<?= $path ?>/images/brand-central.svg" alt="Brand Central Logo" />
        <img class="logo-mobile" src="<?= $path ?>/images/brand-central.svg" alt="Brand Central Logo" />
    </a>
</div>
