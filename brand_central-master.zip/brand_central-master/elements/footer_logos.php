<?php defined('C5_EXECUTE') or die(_("Access Denied.")); ?>

<div class="row">
    <div class="col-md-6 footer-logos footer-logos-left">
    </div>
    <div class="col-md-6 footer-logos footer-logos-right">
    </div>
</div>
