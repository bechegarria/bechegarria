<?php defined('C5_EXECUTE') or die(_("Access Denied.")); ?>

<div class="row">
    <div class="col-md-8 col-12 footer-copyright">
        <span>Copyright © <?=date('Y')?> BrandCentral. All Rights Reserved.</span>
    </div>
</div>
